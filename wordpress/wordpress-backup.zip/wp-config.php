<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the website, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://developer.wordpress.org/advanced-administration/wordpress/wp-config/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wordpress' );

/** Database username */
define( 'DB_USER', 'wordpress' );

/** Database password */
define( 'DB_PASSWORD', ':Y6m@.{Ub{UmXfFr.^0Q0>Sr' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '[:|ib55+YL^gx3c5xUy1q3r1WF5X-9RhMWerqsx4QE>6efD09)INmtd(9w8o:ecC' );
define( 'SECURE_AUTH_KEY',  'dHnI)o@=r{@[ZL1dN(C@{kpI-ALFNU|xv(wyv6SHOwjX1NjEGVxT-DvwU]pmKTH(' );
define( 'LOGGED_IN_KEY',    ']Kilh5Q=uC?@Z>fU+[_mI6E6v,^HT:X.@Dv;UCu+Z8Ly]you:Ny0DqWnZedsBr|G' );
define( 'NONCE_KEY',        'H>_3mN71f3}[n)ZbpQjQpJWPy7O(;x=nS2WxNLSOAF6O1bTgta2]*akzqt[HsVuS' );
define( 'AUTH_SALT',        'q9Lbu15@:U[Jg]+;xMbCRAwXu?:F:**p5DOQ)htLgsGs6;D:RGG]{1L5R,_KA,9{' );
define( 'SECURE_AUTH_SALT', 'nR*B:q6te9BZK225J60J;7O4V?EaPq2BJ:.[5sjBPRnBN,wgmEh---rBDDnijQAO' );
define( 'LOGGED_IN_SALT',   '2DQWF@sGR}2+?I<,t_iW530==nU8::9LRRRr7;qO:e+X^J?<^6BA5_:0=|@:catj' );
define( 'NONCE_SALT',       'B<yd3xD:Vb{jxGA>q]s+2W=MWXD1;vZ=R}DQ;jsCHuQ9=wzbNPZ[D;pHAD:-cxgN' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 *
 * At the installation time, database tables are created with the specified prefix.
 * Changing this value after WordPress is installed will make your site think
 * it has not been installed.
 *
 * @link https://developer.wordpress.org/advanced-administration/wordpress/wp-config/#table-prefix
 */
$table_prefix = 'wp6L5Gwe_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://developer.wordpress.org/advanced-administration/debug/debug-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
